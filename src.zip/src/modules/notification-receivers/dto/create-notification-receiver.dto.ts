export class CreateNotificationReceiverDto {}
