export class CreateNotificationSettingDto {}
