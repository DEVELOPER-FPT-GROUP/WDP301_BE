import {
  IsOptional,
  IsString,
  IsBoolean,
  IsEnum,
  IsNumber,
  Min,
} from 'class-validator';
import { Transform, Type } from 'class-transformer';
import { Gender } from '../../../../utils/enum';

export class SearchMemberDto {
  @IsOptional()
  @IsString()
  email?: string;

  @IsOptional()
  @IsString()
  familyId?: string;

  @IsOptional()
  @Transform(({ value }) => value === 'true') // Chuyển đổi string 'true' thành boolean true
  @IsBoolean()
  isAlive?: boolean;

  @IsOptional()
  @IsEnum(Gender)
  gender?: Gender;

  @IsOptional()
  @IsString()
  search?: string;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  page?: number = 1; // Default page is 1

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  limit?: number = 10; // Default limit is 10

  @IsOptional()
  @Transform(({ value }) => value === 'true') // Chuyển đổi string 'true' thành boolean true
  @IsBoolean()
  isDeleted?: boolean;
}
