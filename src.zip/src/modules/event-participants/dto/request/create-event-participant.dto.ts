export class CreateEventParticipantDto {}
